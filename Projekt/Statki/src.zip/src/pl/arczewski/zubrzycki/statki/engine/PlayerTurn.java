package pl.arczewski.zubrzycki.statki.engine;

public enum PlayerTurn {
    PLAYER1, PLAYER2
}
